//when the user click on item in dashboard activtiy
//this is used to implement that
package com.example.finecloth.customer.interfaces;

//for searchResult and dashboard activity
public interface RecyclerViewClickInterface {


    void onItemClick(int position);
    void onClickButton(int position);


}
