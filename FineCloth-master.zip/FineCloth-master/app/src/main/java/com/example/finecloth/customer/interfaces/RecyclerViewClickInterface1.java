package com.example.finecloth.customer.interfaces;
//for search activity


public interface RecyclerViewClickInterface1 {


    void onItemClick(int position);


}